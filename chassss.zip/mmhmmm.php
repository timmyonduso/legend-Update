<?php

class ContactForm
{
    private string $name;
    private mixed $email;
    private string $message;

    private $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function insert($name, $email, $message)
    {
        // Prepare the statement
        $stmt = $this->pdo->prepare('INSERT INTO contact_form (name, email, message) VALUES (?, ?, ?)');

        // Bind the parameters and execute the statement
        $stmt->execute([$name, $email, $message]);
    }
}

// Connect to the database
$dsn = 'mysql:host=localhost;dbname=mydatabase';
$user = 'dbuser';
$password = 'dbpassword';
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
];
$pdo = new PDO($dsn, $user, $password, $options);

$form = new ContactForm($pdo);

$name = 'John';
$email = 'john@example.com';
$message = 'Hello, world!';
$form->insert($name, $email, $message);


    public function __construct($name, $email, $message)
    {
        $this->name = $name;
        $this->email = $email;
        $this->message = $message;
    }

    public function validate(): bool
    {
        if (empty($this->name) || empty($this->email) || empty($this->message)) {
            return false;
        }

        if (!filter_var($this->email, FILTER_VALIDATE_EMAIL)) {
            return false;
        }

        return true;
    }

    public function send(): bool
    {
        if (!$this->validate()) {
            return false;
        }

        $to = 'director@chaspotinternational.org';
        $subject = 'New Contact Form Submission';
        $headers = "From: {$this->email}" . "\r\n" .
            "Reply-To: {$this->email}" . "\r\n" .
            "X-Mailer: PHP/" . phpversion();

        return mail($to, $subject, $this->message, $headers);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    $form = new ContactForm($name, $email, $message);

    if ($form->send()) {
        // Refresh the page on success
        header('Location: index.html ' . $_SERVER['REQUEST_URI'],'about.html');
        exit;
    }
}


















<?php

return [
    'mail' => [
        'to_email' => 'director@chaspotinternational.org'
    ]
];